package org.prathibha.ordersuplymanagement.model;

public class OrderDetails {
 private Order order;
 private Shipment shipment;
public Order getOrder() {
	return order;
}
public void setOrder(Order order) {
	this.order = order;
}
public Shipment getShipment() {
	return shipment;
}
public void setShipment(Shipment shipment) {
	this.shipment = shipment;
}
 
}
