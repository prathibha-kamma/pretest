package org.prathibha.ordersuplymanagement.model;

public class ProductReq {
	private String productId;

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}
	
}
