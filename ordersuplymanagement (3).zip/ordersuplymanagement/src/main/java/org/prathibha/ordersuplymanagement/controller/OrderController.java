package org.prathibha.ordersuplymanagement.controller;

import org.prathibha.ordersuplymanagement.model.OrderDetails;
import org.prathibha.ordersuplymanagement.model.OrderDetailsRequest;
import org.prathibha.ordersuplymanagement.model.ProductAvailRes;
import org.prathibha.ordersuplymanagement.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class OrderController {
	@Autowired
	private OrderService orderService;
	@Autowired
	private org.prathibha.ordersuplymanagement.service.SupplyService SupplyService;
	
	
	@RequestMapping(value="/getOrderDetails", method=RequestMethod.POST)
	public OrderDetails getOrderDetails(@RequestBody OrderDetailsRequest orderDetailsRequest) {
		
		return orderService.concurrentCall(orderDetailsRequest.getOrderId());
		
	}
	@RequestMapping(value="/getAvailability", method=RequestMethod.POST)
	public ProductAvailRes getAvailability(@RequestBody ProductAvailRes productAvailRes) {
		
		return SupplyService.getAvail(productAvailRes.getProductId());
		
	}

}
