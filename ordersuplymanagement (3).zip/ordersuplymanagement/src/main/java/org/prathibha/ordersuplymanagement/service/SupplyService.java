package org.prathibha.ordersuplymanagement.service;

import java.util.ArrayList;
import java.util.List;

import org.prathibha.ordersuplymanagement.model.Demand;
import org.prathibha.ordersuplymanagement.model.ProductAvailRes;
import org.prathibha.ordersuplymanagement.model.Supply;
import org.springframework.stereotype.Service;

@Service
public class SupplyService {
	private static final List<Supply> supplyList=new ArrayList<Supply>(){{
		add(new Supply("Product1",10));
		add(new Supply("Product2",5));
	}};
	
	private static final List<Demand> demandList=new ArrayList<Demand>(){{
		add(new Demand("Product1",2));
		add(new Demand("Product2",5));
	}};
	public ProductAvailRes getAvail(String prdId) {
		int demcount=0;
		int supcount=0;
		ProductAvailRes productAvailRess=new ProductAvailRes();
		productAvailRess.setProductId(prdId);
		for(Demand demand:demandList) {
			if(demand.getProductId().equalsIgnoreCase(prdId))
				demcount=demand.getQuantity();
		}
		for(Supply supply:supplyList) {
			if(supply.getProductId().equalsIgnoreCase(prdId))
				supcount=supply.getQuantity();
		}
		if(supcount-demcount>0) {
			productAvailRess.setAvailability(supcount-demcount);
		    
		}
		else
			return null;
		 return productAvailRess;
		
	}
	
}
