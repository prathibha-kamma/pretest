package org.prathibha.ordersuplymanagement.model;

public class OrderDetailsRequest {
	private String orderId;

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	

}
