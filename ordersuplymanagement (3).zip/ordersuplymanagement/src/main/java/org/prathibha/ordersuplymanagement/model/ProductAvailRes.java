package org.prathibha.ordersuplymanagement.model;

public class ProductAvailRes {
	private String productId;
	private int availability;
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public int getAvailability() {
		return availability;
	}
	public void setAvailability(int availability) {
		this.availability = availability;
	}
	

}
