package org.prathibha.ordersuplymanagement.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

import org.prathibha.ordersuplymanagement.model.Order;
import org.prathibha.ordersuplymanagement.model.OrderDetails;
import org.prathibha.ordersuplymanagement.model.Shipment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrderService {
	@Autowired
	ExecutorService executorService;
	private static final List<Order> orderList=new ArrayList<Order>(){{
		add(new Order("Order1", "Prod1", 2.0));
	}};
	
	private static final List<Shipment> shipmentList=new ArrayList<Shipment>(){{
		add(new Shipment("Order1", "Ship1", "Prod1", new Date (2021 - 02 - 19), 2.0));
	}};
	OrderDetails orderDetails=new OrderDetails();
	public OrderDetails getOrder(String orderId) {
		
		for(Order order:orderList) {
			if(order.getOrderId().equalsIgnoreCase(orderId))
				orderDetails.setOrder(order);
		}
		return orderDetails;
		
	}
	public OrderDetails getShipmentDetails(String orderId) {
		
		for(Shipment shipment:shipmentList) {
			if(shipment.getOrderId().equalsIgnoreCase(orderId))
				orderDetails.setShipment(shipment);
		}
		return orderDetails;
		
	}
	public OrderDetails concurrentCall(String orderId) {
      Callable<OrderDetails> getOrderRes=()->{
    	  return getOrder(orderId);
      };
      Callable<OrderDetails> getShipRes=()->{
    	  return getShipmentDetails(orderId);
      };
      List<Callable<OrderDetails>> calList=new ArrayList<>();
      calList.add(getOrderRes);
      calList.add(getShipRes);
      OrderDetails OrderDetailsRes=null;
      try {
		List<Future<OrderDetails>> futList=executorService.invokeAll(calList);
		
		for(Future<OrderDetails> future:futList) {
			if(future.isDone()) 
				 OrderDetailsRes=future.get();
			
		}
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (ExecutionException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
      
      
		return OrderDetailsRes;
		
	}
}
