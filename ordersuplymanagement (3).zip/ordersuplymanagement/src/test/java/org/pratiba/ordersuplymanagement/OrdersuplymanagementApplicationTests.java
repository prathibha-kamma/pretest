package org.pratiba.ordersuplymanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrdersuplymanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
